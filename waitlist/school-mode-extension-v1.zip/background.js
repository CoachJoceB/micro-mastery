/* School Mode — background service worker (MV3).
 * Polls the family config from Supabase, caches it locally, and redirects
 * blocked sites to blocked.html while School Mode is active.
 */
'use strict';

importScripts('logic.js');
importScripts('supabase-config.js');

var POLL_MINUTES = 1;
var KEY_PREFIX = 'schoolmode:family:';

function cfgKey(code) { return KEY_PREFIX + code; }

chrome.runtime.onInstalled.addListener(function (details) {
  chrome.alarms.create('sync', { periodInMinutes: POLL_MINUTES });
  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage();
  }
  syncConfig();
});

chrome.runtime.onStartup.addListener(function () {
  syncConfig();
});

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm.name === 'sync') syncConfig();
});

// Re-evaluate enforcement on tab navigation: catches schedule changes
// between polls without waiting for the next sync.
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (changeInfo.status !== 'loading' || !tab.url) return;
  maybeRedirect(tabId, tab.url);
});

chrome.webNavigation.onBeforeNavigate.addListener(function (details) {
  if (details.frameId !== 0) return;
  maybeRedirect(details.tabId, details.url);
});

async function getState() {
  return chrome.storage.local.get(['familyCode', 'familyConfig', 'lastSync']);
}

async function syncConfig() {
  var state = await getState();
  if (!state.familyCode) {
    setBadge('?', '#9ca3af');
    return;
  }
  try {
    var url = SUPABASE_URL + '/rest/v1/command_center?select=value&key=eq.' +
      encodeURIComponent(cfgKey(state.familyCode));
    var res = await fetch(url, {
      headers: { apikey: SUPABASE_ANON, Authorization: 'Bearer ' + SUPABASE_ANON }
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    var rows = await res.json();
    if (rows.length) {
      await chrome.storage.local.set({
        familyConfig: rows[0].value,
        lastSync: Date.now()
      });
    }
  } catch (e) {
    // Offline or unreachable: keep the cached config and keep enforcing.
  }
  updateBadge();
}

async function updateBadge() {
  var state = await getState();
  var cfg = state.familyConfig;
  var enforcing = planAllows(cfg) && isSchoolTime(cfg, new Date());
  if (!state.familyCode) {
    setBadge('?', '#9ca3af');
  } else if (cfg && !planAllows(cfg)) {
    setBadge('!', '#f59e0b'); // plan expired: paused
  } else if (enforcing) {
    setBadge('ON', '#16a34a');
  } else {
    setBadge('', '#16a34a');
  }
  await chrome.storage.local.set({ enforcing: enforcing });
}

function setBadge(text, color) {
  chrome.action.setBadgeText({ text: text });
  chrome.action.setBadgeBackgroundColor({ color: color });
}

async function maybeRedirect(tabId, url) {
  if (!url || url.indexOf('http') !== 0) return;
  if (url.indexOf(chrome.runtime.id) !== -1) return; // our own pages
  var state = await getState();
  var cfg = state.familyConfig;
  if (!planAllows(cfg)) return;
  if (!isSchoolTime(cfg, new Date())) return;
  var host = normalizeHost(url);
  if (isBlockedHost(host, cfg.blocked_sites)) {
    var target = chrome.runtime.getURL('blocked.html') +
      '?host=' + encodeURIComponent(host);
    try {
      await chrome.tabs.update(tabId, { url: target });
    } catch (e) { /* tab closed already */ }
  }
}
