/* School Mode — shared pure logic (no browser APIs except Intl).
 * Used by the extension service worker; unit-tested in Node. */

'use strict';

/** Extract lowercase hostname from a URL string. Returns '' on failure. */
function normalizeHost(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch (e) {
    return '';
  }
}

/** True if host matches a blocked site (exact domain or any subdomain). */
function isBlockedHost(host, blockedSites) {
  host = String(host || '').toLowerCase().trim();
  if (!host) return false;
  var list = blockedSites || [];
  for (var i = 0; i < list.length; i++) {
    var site = String(list[i] || '').toLowerCase().trim().replace(/^www\./, '');
    if (!site) continue;
    if (host === site || host.endsWith('.' + site)) return true;
  }
  return false;
}

/** { day: 0-6 (Sun-Sat), hm: 'HH:MM' } for a Date in the given IANA timezone. */
function partsInTz(date, tz) {
  var dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false
  });
  var parts = dtf.formatToParts(date);
  function get(t) { return parts.find(function (p) { return p.type === t; }).value; }
  var dayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  var hm = get('hour') + ':' + get('minute');
  if (hm === '24:00') hm = '00:00'; // midnight edge in some timezones
  return { day: dayMap[get('weekday')], hm: hm };
}

/**
 * True when School Mode should be enforcing right now.
 * cfg: { school_mode_now, schedule: { enabled, days[], start 'HH:MM', end 'HH:MM', tz } }
 */
function isSchoolTime(cfg, now) {
  if (!cfg) return false;
  if (cfg.school_mode_now) return true; // parent override: ON right now
  var s = cfg.schedule;
  if (!s || !s.enabled) return false;
  var tz = s.tz || 'America/Chicago';
  var p;
  try {
    p = partsInTz(now || new Date(), tz);
  } catch (e) {
    return false;
  }
  if ((s.days || []).indexOf(p.day) === -1) return false;
  return p.hm >= s.start && p.hm <= s.end;
}

/** License gating: only trial/active plans enforce. */
function planAllows(cfg) {
  return !!cfg && (cfg.plan === 'trial' || cfg.plan === 'active');
}

/** Random 6-char family pairing code (no ambiguous chars). */
function makeCode() {
  var chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  var out = '';
  var rnd = new Uint32Array(6);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(rnd);
    for (var i = 0; i < 6; i++) out += chars[rnd[i] % chars.length];
  } else {
    for (var j = 0; j < 6; j++) out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

/** Default family config written on "create family". */
function defaultConfig(code) {
  return {
    code: code,
    family_name: '',
    plan: 'trial',
    plan_started: new Date().toISOString().slice(0, 10),
    school_mode_now: false,
    blocked_sites: [
      'youtube.com', 'youtu.be', 'tiktok.com', 'instagram.com', 'facebook.com',
      'snapchat.com', 'roblox.com', 'twitch.tv', 'discord.com', 'netflix.com',
      'hulu.com', 'disneyplus.com', 'x.com', 'twitter.com', 'reddit.com'
    ],
    schedule: {
      enabled: true,
      days: [1, 2, 3, 4, 5],
      start: '08:00',
      end: '15:00',
      tz: 'America/Chicago'
    },
    kids: [],
    updated_at: new Date().toISOString()
  };
}

// Export for Node tests; harmless in the extension.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    normalizeHost: normalizeHost,
    isBlockedHost: isBlockedHost,
    partsInTz: partsInTz,
    isSchoolTime: isSchoolTime,
    planAllows: planAllows,
    makeCode: makeCode,
    defaultConfig: defaultConfig
  };
}
