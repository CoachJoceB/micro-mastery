/* School Mode — options page: pair/disconnect the device with a family code. */
'use strict';

var KEY_PREFIX = 'schoolmode:family:';

function $(id) { return document.getElementById(id); }

function apiHeaders() {
  return { apikey: SUPABASE_ANON, Authorization: 'Bearer ' + SUPABASE_ANON, 'Content-Type': 'application/json' };
}

async function fetchConfig(code) {
  var url = SUPABASE_URL + '/rest/v1/command_center?select=value&key=eq.' +
    encodeURIComponent(KEY_PREFIX + code.toUpperCase());
  var res = await fetch(url, { headers: apiHeaders() });
  if (!res.ok) throw new Error('Network error ' + res.status);
  var rows = await res.json();
  return rows.length ? rows[0].value : null;
}

async function saveConfig(cfg) {
  cfg.updated_at = new Date().toISOString();
  var url = SUPABASE_URL + '/rest/v1/command_center?on_conflict=key';
  var res = await fetch(url, {
    method: 'POST',
    headers: Object.assign({ Prefer: 'resolution=merge-duplicates' }, apiHeaders()),
    body: JSON.stringify({ key: KEY_PREFIX + cfg.code, value: cfg })
  });
  if (!res.ok) throw new Error('Save failed ' + res.status);
}

async function refreshStatus() {
  var state = await chrome.storage.local.get(['familyCode', 'familyConfig', 'lastSync', 'enforcing']);
  var has = !!state.familyCode;
  $('pair-card').style.display = has ? 'none' : 'block';
  $('status-card').style.display = has ? 'block' : 'none';
  if (!has) return;
  $('show-code').textContent = state.familyCode;
  var cfg = state.familyConfig;
  var pill, planTxt;
  if (!cfg) {
    pill = '<span class="pill off">not synced yet</span>';
    planTxt = '';
  } else if (!planAllows(cfg)) {
    pill = '<span class="pill warn">PAUSED — plan expired</span>';
    planTxt = 'Ask a parent to renew Micro Mastery to turn protection back on.';
  } else if (state.enforcing) {
    pill = '<span class="pill on">ENFORCING NOW</span>';
    planTxt = 'Blocking ' + (cfg.blocked_sites || []).length + ' sites.';
  } else {
    pill = '<span class="pill off">off — outside school hours</span>';
    planTxt = 'Blocking ' + (cfg.blocked_sites || []).length + ' sites when school time starts.';
  }
  var syncTxt = state.lastSync ? 'Last check: ' + new Date(state.lastSync).toLocaleTimeString() : 'Waiting for first check…';
  $('status').innerHTML = pill + '<br><br>' + planTxt + '<br>' + syncTxt;
}

$('connect').addEventListener('click', async function () {
  var code = $('code').value.trim().toUpperCase();
  $('pair-msg').textContent = '';
  if (code.length !== 6) {
    $('pair-msg').textContent = 'Enter the 6-letter code from the parent dashboard.';
    return;
  }
  $('pair-msg').textContent = 'Connecting…';
  try {
    var cfg = await fetchConfig(code);
    if (!cfg) {
      $('pair-msg').textContent = 'No family found with that code. Check the letters and try again.';
      return;
    }
    await chrome.storage.local.set({ familyCode: code, familyConfig: cfg, lastSync: Date.now() });
    await refreshStatus();
  } catch (e) {
    $('pair-msg').textContent = 'Could not reach the server. Check your connection and try again.';
  }
});

$('create').addEventListener('click', async function () {
  $('pair-msg').textContent = 'Creating your family…';
  try {
    var code = makeCode();
    var cfg = defaultConfig(code);
    await saveConfig(cfg);
    await chrome.storage.local.set({ familyCode: code, familyConfig: cfg, lastSync: Date.now() });
    await refreshStatus();
  } catch (e) {
    $('pair-msg').textContent = 'Could not reach the server. Check your connection and try again.';
  }
});

$('disconnect').addEventListener('click', async function () {
  await chrome.storage.local.remove(['familyCode', 'familyConfig', 'enforcing']);
  $('code').value = '';
  await refreshStatus();
});

refreshStatus();
setInterval(refreshStatus, 5000);
